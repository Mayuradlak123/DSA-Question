#include<bits/stdc++.h>
using namespace std;

void Intersection (int n,int m,int i,int j,int a[],int b[]){

     cout << "Intersection of both array"<<endl;
    for(i=0;i<n;i++){

        for(j=0;j<m;j++){

            if(a[i]==b[j]){

                cout << a[i]<<" ";
            }
        }
    }
    
}
int main(){
    
int n,j,i,m;

cout << "Enter size of array 1:"<<endl;

cin>>n;

    int a[n];

    cout <<"Enter size of array 2 "<<endl;

cin>>m;

    int b[m];

    cout <<"ENter element of array 1"<<endl;

for(i=0;i<n;i++){
    cin>>a[i];
}

cout << "Enter element of array 2"<<endl;

    for(i=0;i<m;i++){
        cin>>b[i];
    }
  Intersection(n,m,i,j,a,b);
  return 0;
}