#include<bits/stdc++.h>
using namespace std;
int main(){

    string s="AbCd";
    int i,n;

    for (i=0;i<s.length();i++){
        cout <<s[i];
    }
    return 0;
}