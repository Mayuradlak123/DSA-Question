#include<bits/stdc++.h>
using namespace std;
void Divide(int i,int n,int a[]){
    int k;
    
    int start=0;
    
    int end=n-1;
    
    int mid=start+end/2;
    
    cout << "Enter element if searching: "<<endl;
    
     for(i=0;i<n;i++){

         if(a[mid]==k){

             cout << "Found "<<endl;
             break;
         }
         else if(k>a[mid]){

             start=mid+1;
         }
         else if(k>a[mid]){

             end=mid-1;
         }
         else {
             cout << "Not Found "<<endl;
         }
     }
}
int main(){
    int n,i;
    cout << "Enxer size of  array  : "<<endl;
    cin>>n;

    int a[n];

    cout << "Enter element ofd array "<<endl;
   
    for(i=0;i<n;i++){

        cin>>a[i];
    }
    Divide(n,i,a);
}