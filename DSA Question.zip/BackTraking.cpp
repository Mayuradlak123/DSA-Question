#include<bits/stdc++.h>
using namespace std;
int main(){
    
    int n,i,sum;
    
    cout  << "Enter number of array "<<endl;
    
    cin>>n;
    
    int a[n];
    
    cout << "Enter element of array "<<endl;

    for(i=0;i<n;i++){
        cin>>a[i];
    }

     for(i=0;i<n;i++){
        if(a[i]==a[n-1]){
            cout << "Pallindromic "<<endl;
        }
        else {
            cout << "Not pallindrom"<<endl;
        }
        n--;
        
     }
return 0;
}