#include<bits/stdc++.h>
using namespace std;

int main() {
    
    int n,i;
    cout << "Enter Number of array : "<<endl;
    cin>>n;
    int a[n];
    cout <<"Enter Element of array: "<<endl;
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    int  res=1;
    int  Min=1;
    int Max=1;
   for(i=0;i<n;i++){
       if(a[i]>0){
           Max=Max*a[i];
          Min=min(1,Min*a[i]);
       }
       else if(a[i]==0){
          Max=Min=1;
       }
       else{
           swap(Min,Max);
           Min=Min*a[i];
           Max=max(1,Max*a[i]);
       }
       res=max(Max,res);
   }
   cout <<"Maximum Product sub array : "<<res<<endl;
   return 0;
}