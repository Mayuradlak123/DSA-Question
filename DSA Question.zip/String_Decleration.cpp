#include <bits/stdc++.h>
#include <string>
using namespace std;
     int main()
{

    string s, m;
    cin >> s;
    cin >> m;
    string sg = m + " " + s;
    cout << sg;
    return 0;
}