#include<bits/stdc++.h>
using namespace std;
int main(){
    
    int n,i,j,mid;
    
    cout << "Enter size of array "<<endl;
    
    cin>>n;
    
    int a[n];
    
    cout << "Enter element of array "<<endl;
    
    for(i=0;i<n;i++){
        
        cin>>a[i];
    }
    sort(a,a+n);
    
    j=n-1;
    
    i=0;
    
    cout<< "Alternative Sorted array  "<<endl;
    
      while(i<j){
          
          cout <<a[j--]<<" ";
          
          cout <<a[i++]<<" ";
          
      }
      if(n%2==1){
          
          cout <<a[i]<<" ";
      }
      
    return 0;
}
/*Second Method for solve this problem 
vector<int>v;
     int i=0, j=n-1;
     while(i<=j) {
         v.push_back(arr[j--]);
         v.push_back(arr[i++]);
     }
     for(int i=0; i<n; i++) {
      arr[i]=v[i];     
     }
    }
    This is Very Easy and Important */