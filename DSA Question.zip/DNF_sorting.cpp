
#include <bits/stdc++.h>

using namespace std;
void DNF(int a[],int n){
    
   int l=0;
       int h=n-1;
       int m=0;
       while(m<=h){
           if(a[m]==0){
               swap(a[l],a[m]);
               l++;
               m++;
           }
           else if(a[m]==1){
               m++;
           }
           else if(a[m]==2){
               swap(a[m],a[h]);
               h--;
           }
           else{
               
           }
       }
       cout<< "After Sorting: "<<endl;
       for(int i=0;i<n;i++){
           cout <<a[i]<<" ";
       }
       
    
}
int main()
{
    int i,n;
    cout << "Enter size of array : "<<endl;
    cin>>n;
    int a[n];
    cout << "Enter 0,1,2 for sorting : "<<endl;
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    DNF(a,n);
    
    return 0;
}
