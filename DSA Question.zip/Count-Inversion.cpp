#include "bits/stdc++.h"
using namespace std;
int Count_Inversion(int n,int count,int a[],int i,int j){

      for(i=0;i<n;i++){
    
        for(j=i;j<n;j++){
    
            if(a[i]>a[j]){
    
                count++;
            }
        }
    }
 return count;  
}
int main(){
    
    int j,n,i,count=0;
    
    cout << "Enter size of array : "<<endl;
    
    cin>>n;
    
    int a[n];
    
    cout << "Enter element of array : "<<endl;
    
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    
    cout <<"Total Inversion : "<<Count_Inversion(n,count,a,i,j) <<endl;
    return 0;
}
