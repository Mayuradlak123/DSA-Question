#include<bits/stdc++.h>
using namespace std;

void First_Reapiting(int arr[],int n){
    
    sort(arr,arr+n);
    int i,j;

   for(i=0;i<n;i++){

   	for(j=0;j<i;j++){

   		if(arr[i]==arr[j]){

   			cout <<arr[i]<<endl;

   			break;
   		}
     }
   }
}
int32_t main(){
	
	int n,i,j;
	
	cin>>n;
	
	int arr[n];

	for(i=0;i<n;i++){
		cin>>arr[i];
	}
  
  First_Reapiting(arr,n);
  
   return 0;
}