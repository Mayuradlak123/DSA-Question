#include "bits/stdc++.h"
using namespace std;

class Node {
    public:
    int data;
    Node *next;
    Node(int val){
        data=val;
        next=NULL;
    }
};
void make_loop(Node *head,Node *tail,int pos){
if (pos==0){
    return ;
}
Node *loop=head;
for (int i=1; i<pos; i++){
    loop=loop->next;
   tail->next=loop;
}
}
void print_List(Node *head){
   while(head!=NULL){
    cout <<head->data<<" ";
    head=head->next;
   }
}
bool Detect_loop(Node *head){
    if(!head){
        return false;
    }
    Node *low=head;
    Node *high=head;
    while (high!=NULL and high->next!=NULL)
    {
        low =low->next;
        high=high->next->next;
        if(low==high){
            return true;
        }

    }
    return false;
}
int main(){
    int i,temp,n,pos;
    cout << "Enter size of array : "<<endl;
    cin>>n;
    Node *head;
    Node *tail;
    tail=head;
    cout << "Enter value of head : "<<endl;
    cin>>temp;
    cout << "Enter Position : "<<endl;
    cin>>pos;
    head=tail=new Node(temp);
    cout<< "Enter Element of list : "<<endl;
    for (i=1; i<n; i++){
        cin>>temp;
        tail->next=new Node(temp);
        tail=tail->next;
    }
    cout <<"Element of List : "<<endl;
   make_loop(head,tail,pos);
    // print_List(head);
Detect_loop(head);
    return 0;
}