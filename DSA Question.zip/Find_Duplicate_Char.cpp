#include<bits/stdc++.h>
using namespace std;

void find_Duplicate(string s,int n){
    
    sort(s.begin(),s.end());
    
    for(int i=0;i<n;i++){
        
        if(s[i]==s[i+1]){
            
            cout << s[i]<<" ";
        
        }
    }
  
}
int main(){
    
    string s;
    
    cout << "Enter an char or string : "<<endl;
    
    getline(cin,s);
    
    int n=s.size();
    
    cout << "Duplicate Character in String : "<<endl;
    
    find_Duplicate(s,n);
    
    return 0;
}