#include<bits/stdc++.h>
using namespace std;
int main(){
    
    int n,j,i,maxCount=0,count=0,index=-1;
    
   cout << "Enter size of array : "<<endl;
   
   cin>>n;
    
    int a[n];
    
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    
}