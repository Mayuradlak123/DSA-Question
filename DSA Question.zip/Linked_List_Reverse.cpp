#include <stdlib.h>
#include<iostream>
using namespace std;

class Node {
    public:
    int data;
     Node *next;
    Node(int x)
    {
        data = x;
        next = NULL;
    }
};
class Solution
{
    public:
     Node* reverseList( Node *head)
    {
        if(head==NULL||head->next==NULL)
   {
       return head;
   }
   Node *newhead=reverseList(head->next);
   Node *headnext=head->next;
   headnext->next=head;
   head->next=NULL;
    return newhead;
    }
};

void printList( Node *head)
{ 
    cout << "Element of Linked List: "<<endl;
    
     Node *temp = head;
    while (temp != NULL)
    {
       printf("%d ", temp->data);
       temp  = temp->next;
    }
}

int main()
{
    int n,temp,firstdata;
    cin>>temp;
         Node *head = NULL,  *tail = NULL;
cout <<"Enter size of Linked list : "<<endl;
        cin>>n;
        cout << "Enter Value of Head: "<<endl;

        cin>>firstdata;
        head = new Node(firstdata);
        tail = head;
        cout << "Enter Node of Linked list : "<<endl;
        for (int i=1; i<n; i++)
        {
            cin>>temp;
            tail->next = new Node(temp);
            tail = tail->next;
        }
        
        Solution ob;
        head = ob. reverseList(head);
        
        printList(head);
        cout << endl;
    
    return 0;
}
