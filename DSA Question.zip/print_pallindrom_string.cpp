#include "bits/stdc++.h"
using namespace std;
void print_pallindrom(string str,int n,string t,int i){
    if(i==n){
        string rev=t;
        reverse(t.begin(),t.end());
        if(t==rev){
            cout <<t<<" ";
        }
    }
    else{
        print_pallindrom(str,n,t,i+1);
        t=t+str[i];
        print_pallindrom(str,n,t,i+1);
    }
}
int main(){
    string str;
    cout << "Enter an String : "<<endl;
    cin>>str;
    print_pallindrom(str,str.size(),"",0);
    return 0;
}