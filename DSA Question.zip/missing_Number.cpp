#include "bits/stdc++.h"
using namespace std;
void missing_Number(int n,int arr[]){
    // Sorting they array 
    int i,j,gap;

    for(i=0;i<n;i++){

        for(j=i+1;j<n;j++){

            if(arr[j]<arr[i]){

                swap(arr[j],arr[i]);
            }
        }
    }
    cout <<" Missing Number: ";

    gap=arr[1]-arr[0];

    for(i=0;i<n-1;i++){

        if(arr[i+1]!=arr[i]+gap){
            cout <<arr[i]+gap<<" ";
                        
        }
    }
}
int main(){

    int n,i;
    cout << "Enter Size of Array : "<<endl;
    cin>>n;

    cout << "Enter Element of Array : "<<endl;
    int arr[n];
    
    for(i=0;i<n;i++){
        cin>>arr[i];
    }
  
   missing_Number(n,arr);
   return 0;
}