#include<bits/stdc++.h>
using namespace std;

void Find_Permutaion(string s,int start,int end,int i){
    
    if(start==end){
        
        cout<<s <<" ";
    }
    for(i=start;i<=end;i++){
        
        swap(s[start],s[i]);
    
        Find_Permutaion(s,start+1,end,i);

        swap(s[start],s[i]);

    }
}
int main(){
    string s;
    int n,i,end,start=0;

    cout << "Enter String : "<<endl;
    cin>>s;

    n=s.size();

    end=n-1;

     Find_Permutaion(s,start,end,i);

    return 0;
}