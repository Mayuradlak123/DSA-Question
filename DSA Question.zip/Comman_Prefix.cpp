#include<bits/stdc++.h>
using namespace std;
string  Prefix(string str[],int n){
    
    string ans  ="";
     sort(str,str+n);
    string a=str[0],b=str[n-1];
      for(int i=0;i<a.size();i++)
      {
          if(a[i]==b[i]){
            ans+=a[i];  
          } 
          else{
            break;
          }
      }
      if(ans=="") 
      {
          return "-1";
      }
      else{
        return ans;     
      }
}
int main(){
    
    int i,n;
    cout  <<  "Enter size of String : "<<endl;
    cin>>n;
    string str[n];
   for ( i = 0; i < n; i++)
   {
       cin>>str[i];
       /* code */
   }
   
   cout << "Longest comman pefix: "<<Prefix(str,n);
   return 0;
}