#include "bits/stdc++.h"
using namespace std;
long long count_divisible(int a[],int n,int k){
       long long ans=0;
       int i;
       unordered_map<int,int > m;

       for(i=0;i<n;i++){
           int rem=a[i]%k;
           if(rem!=0){
               ans=ans+m[k-a[i]%k];
               
           }
           else{
               ans+=m[0];
               m[rem]++;
           
           }
       }
}
int main(){
   int i,n;
    cin>>n;

    int a[n];
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    int  k;
    cin>>k;
    cout <<count_divisible(a,n,k);
    return 0;
}