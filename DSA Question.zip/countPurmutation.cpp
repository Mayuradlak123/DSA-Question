#include<iostream>
#include<string.h>
using namespace std;
int main (){
    string s;
    cout<< "Enter a String : "<<endl;
    cin>>s;
    cout << "0th Index "<<s[0]<<endl;
}