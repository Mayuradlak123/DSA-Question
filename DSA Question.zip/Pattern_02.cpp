#include<iostream>
using namespace std;

int main(){
    int i,j;
    for(i=1;i<=5;i++){
        for(j=i;j<=5;j++){
            cout <<i;
        }
        cout<<endl;
    }
    return 0;
}
/* Output
11111
2222
333
44
5
 */