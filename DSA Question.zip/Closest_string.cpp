#include<bits/stdc++.h>
using namespace std;

int closet(string str[],string word1,string word2,int n){

    int sum=1,i;

    for(i=0;i<n;i++){

        while(str[i]!=word2){

            if(str[i]==word1){
                
                sum++;
            }
        }
    }
    return sum;
}
int main(){

    int i,n;

    cin>>n;

    string str[n],word1,word2;

    for(i=0;i<n;i++){

        cin>>str[i];
    }
    cin>>word1>>word2;

    cout <<closet(str,word1,word2,n)<<endl;

    return 0;
}