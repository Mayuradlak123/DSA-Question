#include<bits/stdc++.h>
using namespace std;
void Subsequence(string s,string sub){

    if(s.empty()){
        
        cout <<sub<<" ";
        return ;
    }
    Subsequence(s.substr(1),sub+s[0]);
    
    Subsequence(s.substr(1),sub);
}
int main(){
	
	string s;
	
	string sub=" ";
	int i,j;
	
	cout <<"Enter an string "<<endl;

	cin>>s;
    
    Subsequence(s,sub);

    return 0;
}