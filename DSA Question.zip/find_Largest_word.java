// import java.util.Scanner;
// import java.util.Vector;

// public class find_Largest_word{
//     Scanner sc= new Scanner(System.in);
//     Vector<String> v=new Vector<>();
//     String s;
//    public void Input(){
//        System.out.println("Enter size of Str: ");
//        Collections.sort(d); String res="";
//        for(String s: d){
//            int i=0,j=0; int n1=S.length(), n2=s.length();
//            if(n2>n1) continue;
//            while(i<n1 && j<n2 ){
//                if(S.charAt(i) == s.charAt(j) ){
//                    j++;
//                }
//                i++;
//            }
//            if(j==n2 && res.length()<s.length() ){
//                res=s;
//            }
//        }
//        return res;
//    }
//    }
// }