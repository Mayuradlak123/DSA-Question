#include<iostream>
using namespace std;
int main(){

    int n,i,j;
   
    cout << "Enter size of array : "<<endl;
   
    cin>>n;
   
    int a[n];
   
    cout << "ENter element  of array : "<<endl;
   
    for(i=0;i<n;i++){
        cin>>a[i];
    }
   
    int Sum,count=0;
   
    cout << "Enter sum for check : "<<endl;
   
    cin>>Sum;
   
    for(i=0;i<n;i++){
   
        for(j=i+1;j<n;j++){
   
        if(a[i]+a[j]==Sum){
   
            count++;
        }
    }
}
/*unordered_map<int ,int >m;
         int count=0;
         for(int i=0;i<n;i++)
         {
             if(m.find(k-a[i])!=m.end())
             {
                 count=count+m[k-a[i]];
             }
             m[a[i]]++;
             
         }
        return count; 
        }*/
    cout << "Posiible Sum : "<<count<<endl;

return 0;
}