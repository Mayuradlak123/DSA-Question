#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,i;
    
    cout << "Enter Size of array "<<endl;
    
    cin>>n;
    
    int a[n];
    
    cout << "Enter element of array "<<endl;
    
    for(i=0;i<n;i++){

        cin>>a[i];
    }
    
    cout << "Peek element "<<endl;
    
    for(i=0;i<n;i++){

        if(a[i+1]<a[i] && a[i-1]<a[i]){

            cout << a[i] <<" ";
        }
    }
      return 0;
}
