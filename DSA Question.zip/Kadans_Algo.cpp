#include "bits/stdc++.h"
using namespace std;
int Maximum_sum(int n,int arr[]){

    int i,ans=INT_MIN,sum=0;

    for (i=0; i<n; i++){

        sum+=arr[i];
        ans=max(sum,ans);
        
        if(sum<0){
            sum=0;
        }
    }
    return ans;
}
int main(){
    int n,i;
    cout << "Enter size of array : "<<endl;
    cin>>n;

    int arr[n];
    cout <<"Enter Element of array : "<<endl;
    
    for (i=0; i<n; i++){
        cin>>arr[i];
    }
    
    cout <<"Maximum sum in Subarray: "<<Maximum_sum(n,arr)<<endl;
    return 0;
}