#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *next;
};
void Traversal(Node *n){
    while (n!=NULL)
    {
        
    cout<<n->data<<"->";

    n= n->next;
     
    }
    cout<<"NULL"<<endl;   
}
int main(){
    Node *newNode=NULL; 

    Node *head=NULL;

    Node *second=NULL;

    Node *Third=NULL;

    Node *Fourth=NULL;

    newNode=new Node();

    head=new Node();

   second =new Node();

   Third=new Node();

Fourth=new Node();

newNode->data=10;

newNode->next=head;

head->data=77;

head->next=second;

second->data=12;

second->next=Third;

Third->data=45;

Third->next=Fourth;

Fourth->data=14;

Fourth->next=NULL;

Traversal(newNode);

}