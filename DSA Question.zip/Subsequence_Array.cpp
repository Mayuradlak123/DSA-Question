#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,i,j,k;

    cout <<" Enter size of array : "<<endl;

    cin>>n;

    int a[n];

    cout <<"Enter element of array :"<<endl;

    for(i=0;i<n;i++){

        cin>>a[i];
    }
    cout <<"Subsequence of given array : "<<endl;

    for(i=0;i<n;i++){

        for(j=i;j<n;j++){

            for(k=i;k<=j;k++){
                
                cout <<a[k]<<" ";
            }
            cout <<endl;
        }
    }
}