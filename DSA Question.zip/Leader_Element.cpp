#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,i,j;
    
    cout << "Enter size of array "<<endl;
    
    cin>>n;
    
    int a[n];
    
    cout << "Enter element of array "<<endl;
    
    for(i=0;i<n;i++){

        cin>>a[i];
    }
    cout << "Leader Element in This Array :"<<endl;
    
    for(i=0;i<n;i++){

        for(j=i+1;j<n;j++){

            if(a[i]<=a[j]){

               break;
            }
        }
        if(j==n){
            
            cout <<a[i]<<" ";
        }
        //if(j==(n-1)){
    }
    
    return 0;
}