#include "bits/stdc++.h"
using namespace std;
string  count_and_Say(int n){
    int i,j,c;
        string s="11";
        // string t="";
        for(i=3;i<=n;i++){
            string t="";
            s=s+' ';
            int c=1;
            for(j=1;i<s.size();j++){
                if(s[j]!=s[j-1]){
                    t=t+to_string(c);
                    t=t+s[j-1];
                    c=1;
            }
                else{
                    c++;
                }
                s=t;
            }
        }
            return s;
    }  
int main(){
    int n;
   
   cout << "Enter an int : "<<endl;

   cin>>n;
   cout <<count_and_Say(n)<<endl;
}